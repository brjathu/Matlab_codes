PM=40;
ess= 0.01;

%open loop plant
numerator = 3 * [1 3];
denominator = conv([1 4],[1 3 20]);

G= tf(numerator, denominator);
bode(G); 
grid on;
hold on;
[gain, phase] = bode(G,20);